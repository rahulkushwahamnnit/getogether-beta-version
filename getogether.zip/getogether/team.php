<html>
<title>RAHUL KUSHWAHA</title>
<style type="text/css">
li a{
	text-decoration:none;
font-size:16px;
}
li a:hover{
	text-decoration:underline;
font-size:16px;
}

</style>
<body>
<h2></h2>
<div style="width:300px;">
<center><img src="img/ceo.jpg" height="200" width="200"></center>
<center><h2>RAHUL KUSHWAHA</h2></center>
<h2>About Me:</h2>
<b>I am currently pursuing my Btech in E.C.E. from Motilal Nehru National Institute Of Technology, Allahabad.
I belongs to a very small district in madhya pradesh.
I love coding and web designing and my skills are html, css, php, mysql and c.</b>
<h2>Contact Details:</h2>
<b>Email:</b> kushwaharesonance@gmail.com
<h2> My Links:</h2>
<ul style="list-style:none;">

<li><a href="https://www.facebook.com/farzirahu">facebook</a></li>
<li><a href="https://twitter.com/farzirahu">twitter</a></li>
<li><a href="http://in.linkedin.com/in/farzirahu/">linkedin</a></li>
<li><a href="https://www.quora.com/Rahul-Kushwaha-11">quora</a></li>
<li><a href="https://plus.google.com/+rahulkushwahafarzirahu/">google+</a></li>
<li><a href="http://www.codechef.com/users/farzirahu">codechef</a></li>
<li><a href="http://rahul-kushwaha.blogspot.com">my blog</a></li>
<!--<li><a href="http://www.scribd.com/farzirahu">scribd</a></li>
<li><a href="http://www.slideshare.net/rahulkushwaha7">slide share</a></li>-->
</ul>
</div>
</body>
</html>