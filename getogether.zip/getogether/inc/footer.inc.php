
  Copyright © 2014 | <a style="text-decoration:none;" href="home.php">GeTogether</a> | All rights reserved.
  </div>
</body>
</html>