<?php
//mysql_connect("localhost","","") or die("couldn't connect to sql server");
//mysql_select_db("getogether") or die("couldn't select DB");
mysqli_connect("localhost","root","toor","getogether") or die("couldn't select DB");
?>